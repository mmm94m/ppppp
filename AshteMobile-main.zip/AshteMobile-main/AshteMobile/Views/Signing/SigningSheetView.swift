import SwiftUI
import Combine
import PhotosUI

struct SigningSheetView: View {
    let entryID: UUID
    var onSignedSuccessfully: (() -> Void)?

    @ObservedObject private var library = AppLibraryStore.shared
    @ObservedObject private var certificateStore = CertificateStore.shared
    @ObservedObject private var presetStore = PresetStore.shared
    @ObservedObject private var defaultsStore = DefaultSigningOptionsStore.shared

    @State private var options = SigningOptions()
    @State private var certificateID: UUID?
    @State private var isSigning = false
    @State private var jobStatus: SigningJobStatus = .queued
    @State private var errorMessage: String?
    @State private var showingSavePreset = false
    @State private var presetName = ""
    @State private var pickedIconItem: PhotosPickerItem?
    @State private var iconImportError: String?
    @State private var hasSeededDefaults = false

    @Environment(\.dismiss) private var dismiss

    private var entry: AppEntry? {
        library.apps.first { $0.id == entryID }
    }

    var body: some View {
        NavigationStack {
            Form {
                if let entry {
                    headerSection(entry: entry)
                    if isSigning {
                        progressSection
                            .transition(.opacity.combined(with: .move(edge: .top)))
                    }
                    certificateSection
                    identitySection(entry: entry)
                    SigningOptionsEditor(options: $options, certificateID: certificateID, layout: .compact)
                }
            }
            .animation(.easeOut(duration: 0.25), value: isSigning)
            .siScreen()
            .presentationDragIndicator(.visible)
            .navigationTitle("Sign")
            .navigationBarTitleDisplayMode(.inline)
            .disabled(isSigning)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .primaryAction) {
                    presetMenu
                }
            }
            .safeAreaInset(edge: .bottom) {
                Button {
                    sign()
                } label: {
                    HStack(spacing: SISpacing.sm) {
                        if isSigning {
                            ProgressView().tint(SIColor.onAccent)
                        } else {
                            Image(systemName: "signature")
                        }
                        Text("Sign")
                    }
                }
                .buttonStyle(.siPrimaryWide)
                .disabled(certificateID == nil || isSigning)
                .opacity(certificateID == nil ? 0.45 : 1)
                .padding(.horizontal, SISpacing.md)
                .padding(.vertical, SISpacing.sm)
                .background(.ultraThinMaterial)
            }
            .onAppear(perform: prepareDefaults)
            .onChange(of: pickedIconItem) { newItem in
                guard let newItem else { return }
                loadPickedIcon(newItem)
            }
            .alert("Signing Failed", isPresented: Binding(get: { errorMessage != nil }, set: { if !$0 { errorMessage = nil } })) {
                Button("OK") { errorMessage = nil }
            } message: {
                Text(errorMessage ?? "")
            }
            .alert("Couldn't Use That Image", isPresented: Binding(get: { iconImportError != nil }, set: { if !$0 { iconImportError = nil } })) {
                Button("OK") { iconImportError = nil }
            } message: {
                Text(iconImportError ?? "")
            }
            .sheet(isPresented: $showingSavePreset) {
                NameInputSheet(title: String(localized: "Save Preset"), placeholder: String(localized: "Preset name"), text: "", confirmTitle: String(localized: "Save")) { name in
                    presetStore.save(name: name, certificateID: certificateID, options: options)
                }
            }
        }
    }

    private func headerSection(entry: AppEntry) -> some View {
        Section {
            HStack(spacing: SISpacing.md) {
                iconPreview(for: entry)
                    .frame(width: 64, height: 64)
                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 15, style: .continuous).stroke(SIColor.border.opacity(0.6), lineWidth: 0.5))
                VStack(alignment: .leading, spacing: 3) {
                    Text(entry.name)
                        .font(.system(.title3, design: .rounded).weight(.bold))
                        .foregroundStyle(SIColor.textPrimary)
                        .lineLimit(1)
                    Text(entry.bundleIdentifier)
                        .font(SIFont.caption)
                        .foregroundStyle(SIColor.textSecondary)
                        .lineLimit(1)
                    Text("\(entry.displayVersion) · \(entry.displaySize)")
                        .font(.system(size: 11, weight: .semibold, design: .rounded))
                        .foregroundStyle(SIColor.accent)
                }
                Spacer(minLength: 0)
            }
            .padding(.vertical, SISpacing.xs)
        }
        .listRowBackground(
            LinearGradient(colors: [SIColor.accent.opacity(0.18), SIColor.surface], startPoint: .topLeading, endPoint: .bottomTrailing)
        )
    }

    private var presetMenu: some View {
        Menu {
            if !presetStore.presets.isEmpty {
                Section("Load Preset") {
                    ForEach(presetStore.presets) { preset in
                        Button(preset.name) {
                            options = preset.options
                            certificateID = preset.certificateID ?? certificateID
                            presetStore.markUsed(preset)
                        }
                    }
                }
            }
            Button {
                showingSavePreset = true
            } label: {
                Label("Save Current as Preset", systemImage: "square.and.arrow.down.on.square")
            }
        } label: {
            Image(systemName: "slider.horizontal.3")
        }
        .accessibilityLabel(Text("Presets"))
    }

    private var certificateSection: some View {
        Section {
            if certificateStore.certificates.isEmpty {
                Text("Add a certificate in Settings first.")
                    .font(SIFont.caption)
                    .foregroundStyle(SIColor.danger)
            } else {
                Picker("Certificate", selection: $certificateID) {
                    ForEach(certificateStore.certificates) { certificate in
                        Text(certificate.name)
                            .tag(UUID?.some(certificate.id))
                    }
                }
            }
        }
        .siRowBackground()
    }

    private var certificateBundleID: String? {
        certificateStore.profileBundleIdentifier(forCertificateID: certificateID)
    }

    private func identitySection(entry: AppEntry) -> some View {
        let original = entry.originalBundleIdentifier ?? entry.bundleIdentifier
        return Section {
            TextField("Display Name", text: $options.displayName)
                .autocorrectionDisabled()

            HStack(spacing: SISpacing.md) {
                iconPreview(for: entry)
                    .frame(width: 44, height: 44)
                    .clipShape(RoundedRectangle(cornerRadius: SIRadius.sm, style: .continuous))

                Text(options.customIconPath == nil ? String(localized: "App Icon") : String(localized: "Custom Icon"))

                Spacer()

                PhotosPicker(selection: $pickedIconItem, matching: .images) {
                    Text(options.customIconPath == nil ? "Choose" : "Change")
                }

                if options.customIconPath != nil {
                    Button(role: .destructive) {
                        resetIcon()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(SIColor.danger)
                }
            }

            Picker("Bundle ID", selection: $options.bundleIdentifierRule) {
                ForEach(BundleIdentifierRule.allCases) { rule in
                    Text(rule.displayName).tag(rule)
                }
            }

            switch options.bundleIdentifierRule {
            case .appendSuffix:
                TextField("Suffix", text: $options.bundleIdentifierSuffix)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
            case .custom:
                TextField("com.example.app", text: $options.bundleIdentifier)
                    .autocorrectionDisabled()
                    .textInputAutocapitalization(.never)
                if let certificateBundleID {
                    Button {
                        options.bundleIdentifier = SigningOptions.bundleIdentifier(fromCertificateID: certificateBundleID, original: original)
                    } label: {
                        Label("Use Bundle ID from Certificate", systemImage: "checkmark.seal")
                    }
                }
            default:
                EmptyView()
            }

            HStack {
                TextField("Version", text: $options.version)
                Divider()
                TextField("Build", text: $options.build)
            }
            .keyboardType(.numbersAndPunctuation)

            TextField("Minimum iOS Version", text: $options.minimumOSVersion)
                .keyboardType(.numbersAndPunctuation)
        } header: {
            Text("Identity")
        } footer: {
            identityFooter(original: original)
        }
        .siRowBackground()
    }

    @ViewBuilder
    private func iconPreview(for entry: AppEntry) -> some View {
        if let path = options.customIconPath, let image = UIImage(contentsOfFile: path) {
            Image(uiImage: image).resizable().scaledToFill()
        } else if let url = library.iconURL(for: entry), let image = UIImage(contentsOfFile: url.path) {
            Image(uiImage: image).resizable().scaledToFill()
        } else {
            RoundedRectangle(cornerRadius: SIRadius.sm, style: .continuous)
                .fill(SIColor.surfaceElevated)
                .overlay(Image(systemName: "app.dashed").foregroundStyle(SIColor.textSecondary))
        }
    }

    private func loadPickedIcon(_ item: PhotosPickerItem) {
        Task {
            do {
                guard let data = try await item.loadTransferable(type: Data.self), let image = UIImage(data: data) else {
                    await MainActor.run { iconImportError = String(localized: "Couldn't load that image.") }
                    return
                }
                guard let pngData = image.pngData() else {
                    await MainActor.run { iconImportError = String(localized: "Couldn't convert that image to PNG.") }
                    return
                }
                let url = FileManager.default.temporaryDirectory.appendingPathComponent("\(UUID().uuidString)-icon.png")
                try pngData.write(to: url)
                await MainActor.run {
                    if let previousPath = options.customIconPath {
                        try? FileManager.default.removeItem(atPath: previousPath)
                    }
                    options.customIconPath = url.path
                    pickedIconItem = nil
                }
            } catch {
                await MainActor.run { iconImportError = error.localizedDescription }
            }
        }
    }

    private func resetIcon() {
        if let path = options.customIconPath {
            try? FileManager.default.removeItem(atPath: path)
        }
        options.customIconPath = nil
    }

    @ViewBuilder
    private func identityFooter(original: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            if options.bundleIdentifierRule == .randomSuffix {
                Text("Original bundle ID: \(original)")
            } else {
                let resolved = options.resolvedBundleIdentifier(original: original, certificateBundleID: certificateBundleID)
                Text("Signs as: \(resolved)")
                if resolved != original {
                    Text("Original bundle ID: \(original)")
                }
            }
            if let certificateBundleID {
                Text("Certificate bundle ID: \(certificateBundleID)")
                if options.bundleIdentifierRule == .fromCertificate, certificateBundleID == "*" {
                    Text("This certificate is a wildcard, so the original bundle ID is kept.")
                }
            } else if options.bundleIdentifierRule == .fromCertificate {
                Text("Couldn't read a bundle ID from this certificate's profile, so the original is kept.")
            }
        }
    }

    private var progressSection: some View {
        Section {
            HStack(spacing: SISpacing.sm) {
                if jobStatus.isInProgress {
                    ProgressView()
                }
                signingProgressFooter
                    .transition(.opacity)
            }
            .animation(.easeOut(duration: 0.2), value: jobStatus)
        }
        .siRowBackground()
    }

    @ViewBuilder
    private var signingProgressFooter: some View {
        switch jobStatus {
        case .queued: Text("Queued…")
        case .extracting: Text("Unpacking IPA…")
        case .patching: Text("Applying modifiers…")
        case .signing: Text("Signing with zsign…")
        case .packaging: Text("Repacking IPA…")
        case .cached: Text("Found an identical signed build in cache — skipping re-sign…")
        case .done(let seconds):
            if seconds < 0.05 {
                Text("Done instantly from cache.")
            } else {
                Text(String(format: String(localized: "Done in %.1fs."), seconds))
            }
        case .failed(let message): Text(message).foregroundStyle(SIColor.danger)
        }
    }

    private func prepareDefaults() {
        guard let entry else { return }
        certificateID = certificateStore.defaultCertificateID ?? certificateStore.certificates.first?.id
        guard !hasSeededDefaults else { return }
        hasSeededDefaults = true
        options = defaultsStore.makeOptions(seededWith: entry)
    }

    private func sign() {
        guard let entry, let certificateID else { return }
        isSigning = true

        let job = SigningJob(
            appEntryID: entry.id,
            sourceIPAURL: library.ipaURL(for: entry),
            displayName: entry.name,
            options: options,
            certificateID: certificateID
        )

        Task {
            let cancellable = job.$status.sink { status in
                Task { @MainActor in jobStatus = status }
            }
            await SigningEngine.shared.run(jobs: [job])
            cancellable.cancel()

            await MainActor.run {
                isSigning = false
                if case .failed(let message) = job.status {
                    errorMessage = message
                } else {
                    let shouldInstall = options.installAfterSigning
                    dismiss()
                    if shouldInstall {
                        onSignedSuccessfully?()
                    }
                }
            }
        }
    }
}
